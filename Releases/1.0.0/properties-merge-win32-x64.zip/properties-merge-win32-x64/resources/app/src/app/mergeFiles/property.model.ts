export class Property {
    constructor(
        public line: number,
        public name: string,
        public value: string,
    ) { 
        
    }
}