import { Component } from "@angular/core";


@Component( {
    selector: "delimiter",
    moduleId: module.id,
    template: `<div class="container" style="min-height: 40px;"></div>`
} )
export class DelimiterComponent {

    // MARK: - Local Variables

    // MARK: - Actions

    // MARK: - Outlets

    // MARK: - LIFE Component
    constructor() { }

    // MARK: - Utils


}