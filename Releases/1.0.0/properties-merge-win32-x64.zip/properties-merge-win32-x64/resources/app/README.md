# Properties merge

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.7.4.

## Description

Can merge 2 properties files. Allows filtering by:
 - Equals lines.
 - Different lines.
 - Left side lines.
 - Right side lines.

After you choose wich lines to import, it generates a merged file with all the information.

Allows to check conflicts between files, with an "automate-merge" fucntionallity.